window.onload = ()=>{
    //利用数组插入导航栏信息
    let head_nav_arr = [
    {title:"游戏资料",subtitle:"GAME INFO"},
    {title:"商城/合作",subtitle:"STORE"},
    {title:"社区互动",subtitle:"COMMUNITY"},
    {title:"赛事官网",subtitle:"ESPORTS"},
    {title:"自助系统",subtitle:"SYSTEM"},
    ];
    
    let head_nav_title = document.getElementsByClassName("head_nav_title");
    let head_nav_subtitle = document.getElementsByClassName("head_nav_subtitle");
    for(let i=0; i<head_nav_arr.length;i++){
        head_nav_title[i].innerHTML = head_nav_arr[i].title;
        head_nav_subtitle[i].innerHTML = head_nav_arr[i].subtitle;
    }

    //插入导航栏子菜单信息
    let header_Bf_inner_arr = [
        {url:"#",title:"游戏下载"},
        {url:"#",title:"点券充值"},
        {url:"#",title:"官方社区"},
        {url:"#",class:"logo_h",title:"LPL职业联赛"},
        {url:"#",title:"联系客服"},
        {url:"#",title:"新手指引"},
        {url:"#",class:"logo_h",title:"道聚城"},
        {url:"#",title:"视频中心"},
        {url:"#",title:"LDL发展联赛"},
        {url:"#",class:"logo_n",title:"转区系统"},
        {url:"#",title:"资料库"},
        {url:"#",title:"周边商城"},
        {url:"#",title:"官方论坛"},
        {url:"#",class:"logo_h",title:"全球总决赛"},
        {url:"#",class:"logo_h",title:"封号查询"},
        {url:"#",class:"logo_n",title:"云顶之弈"},
        {url:"#",title:"LOL桌游"},
        {url:"#",title:"官方微信"},
        {url:"#",title:"城市英雄争霸赛"},
        {url:"#",title:"账号注销"},
        {url:"#",class:"logo_n",title:"攻略中心"},
        {url:"#",title:"网吧特权"},
        {url:"#",title:"官方微博"},
        {url:"#",class:"logo_n",title:"季中杯"},
        {url:"#",class:"logo_n",title:"信誉分系统"},
        {url:"#",title:"开发者基地"},
        {url:"#",title:"电竞小说"},
        {url:"#",title:"玩家创作馆"},
        {url:"#",title:"德玛西亚杯"},
        {url:"#",title:"服务器状态查询"},
        {url:"#",title:"海克斯战利品库"},
        {url:"#",class:"logo_n",title:"作者入驻计划"},
        {url:"#",title:"玩家服务"},
        {url:"#",title:"全国高校联赛"},
        {url:"#",title:"秩序殿堂"},
        {url:"#",title:"英雄联盟宇宙"},
        {url:"#",title:""},
        {url:"#",class:"logo_n",title:"LOL组队专区"},
        {url:"#",class:"logo_n",title:"云顶之弈公开赛"},
        {url:"#",title:"峡谷之巅"}
    ];
    let header_Bf_inner = document.getElementById("header_Bf_inner");
    let html = '';
    for(let i=0; i<header_Bf_inner_arr.length; i++){
        html += '<li><a href="'+header_Bf_inner_arr[i].url+'">'+'<div class = "'+ header_Bf_inner_arr[i].class +'"></div>'+header_Bf_inner_arr[i].title+'</a></li>';
    }
    header_Bf_inner.innerHTML = html;

    //绑定鼠标移入head_nav事件
    let head_nav = document.getElementById("head_nav");
    let header_Bf = document.getElementById("header_Bf");
    head_nav.onmouseover = ()=>{
        header_Bf.style.display = "block";
    }
    //绑定鼠标移出head_nav事件
    header_Bf.onmouseleave = ()=>{
        header_Bf.style.display = "none";
    }
    
    let head_search = document.getElementsByClassName("head_search")[0];
    let head_search_onclick = document.getElementsByClassName("head_search_onclick")[0];
    let head_search_close = document.getElementsByClassName("head_search_close")[0];
    //绑定搜索按钮点击事件
    head_search.onclick = ()=>{
        head_search_onclick.style.display = "block";
    }
    //绑定关闭搜索按钮点击事件
    head_search_close.onclick = ()=>{
        head_search_onclick.style.display = "none";
    }

    //绑定鼠标移入出现下载二维码事件
    let head_app = document.getElementsByClassName("head_app")[0];
    let head_app_hover = document.getElementsByClassName("head_app_hover")[0];
    head_app.onmouseover = ()=>{
        head_app_hover.style.display = "block";
    }
    //移出
    head_app_hover.onmouseleave = ()=>{
        head_app_hover.style.display = "none";
    }

    //绑定鼠标移入出现登录信息事件
    let head_login = document.getElementsByClassName("head_login")[0];
    let head_login_hover = document.getElementsByClassName("head_login_hover")[0];
    head_login.onmouseover = ()=>{
        head_login_hover.style.display = "block";
    }
    //移出
    head_login_hover.onmouseleave = ()=>{
        head_login_hover.style.display = "none";
    }

    //插入Af_news列表
    let Af_news = document.getElementsByClassName("Af_news")[0];
    let Af_news_arr = [
        {title:"综合"},
        {title:"公告"},
        {title:"赛事"},
        {title:"攻略"},
        {title:"社区"}
    ];
    let html_news = '';
    for(let i=0; i<Af_news_arr.length; i++){
        html_news += '<li>'+ Af_news_arr[i].title +'</li>'
    }
    
    Af_news.innerHTML = html_news;

    //插入Af_news_total《综合》列表
    let Af_news_total = document.getElementsByClassName("Af_news_total")[0];
    let Af_news_total_arr = [
        {title:"title_yes",spanName1:"",class:"",content:"全球总决赛事件现已开启",spanName2:"span_date",date:""},
        {title:"title_no",spanName1:"video",class:"视频",content:"全球总决赛上海城市峡谷宣传片：峡谷在每一个有英雄的地方！",spanName2:"span_date",date:"10-03"},
        {title:"title_no",spanName1:"video",class:"视频",content:"全球总决赛出征-SN：低调是真实的谦虚，勤恳是进步的法门",spanName2:"span_date",date:"10-04"},
        {title:"title_no",spanName1:"video",class:"视频",content:"巨型水晶打卡火热现场，彰显总决赛全民助威激情！",spanName2:"span_date",date:"10-05"},
        {title:"title_no",spanName1:"video",class:"视频",content:"助威启动仪式，光影艺术诠释上海城市峡谷",spanName2:"span_date",date:"10-06"},
        {title:"title_no",spanName1:"competition",class:"赛事",content:"拳头：2020全球总决赛最强选手20人！",spanName2:"span_date",date:"10-07"}
    ]
    let html_total = '';
    for(let i=0; i<Af_news_total_arr.length; i++){
        html_total += '<li class="'+ Af_news_total_arr[i].title +'"><span class="'+ Af_news_total_arr[i].spanName1 +'">'+ Af_news_total_arr[i].class +'</span><a href="#">'+ Af_news_total_arr[i].content +'</a><span class="'+ Af_news_total_arr[i].spanName2 +'">'+ Af_news_total_arr[i].date +'</span></li>'
    }
    Af_news_total.innerHTML = html_total;

    //插入Af_news_notice《公告》列表
    let Af_news_notice = document.getElementsByClassName("Af_news_total")[1];
    let Af_news_notice_arr = [
        {title:"title_yes",spanName1:"",class:"",content:"欢度中秋活动公告",spanName2:"span_date",date:""},
        {title:"title_no",spanName1:"notice",class:"公告",content:"河流之王禁用公告",spanName2:"span_date",date:"10-07"},
        {title:"title_no",spanName1:"notice",class:"公告",content:"关于开放世界赛主题冠军杯赛的公告",spanName2:"span_date",date:"10-04"},
        {title:"title_no",spanName1:"notice",class:"公告",content:"兽灵行者乌迪尔禁用公告",spanName2:"span_date",date:"10-05"},
        {title:"title_no",spanName1:"notice",class:"公告",content:"10月2日免费英雄更换公告",spanName2:"span_date",date:"10-06"},
        {title:"title_no",spanName1:"notice",class:"公告",content:"全球总决赛事件现已开启",spanName2:"span_date",date:"10-07"}
    ]
    let html_notice = '';
    for(let i=0; i<Af_news_notice_arr.length; i++){
        html_notice += '<li class="'+ Af_news_notice_arr[i].title +'"><span class="'+ Af_news_notice_arr[i].spanName1 +'">'+ Af_news_notice_arr[i].class +'</span><a href="#">'+ Af_news_notice_arr[i].content +'</a><span class="'+ Af_news_notice_arr[i].spanName2 +'">'+ Af_news_notice_arr[i].date +'</span></li>'
    }
    Af_news_notice.innerHTML = html_notice;

    //插入Af_news_total《赛事》列表
    let Af_news_competiton = document.getElementsByClassName("Af_news_total")[2];
    let Af_news_competiton_arr = [
        {title:"title_yes",spanName1:"",class:"",content:"英雄麦克疯：LPL再获全胜，我们势不可挡",spanName2:"span_date",date:""},
        {title:"title_no",spanName1:"competition",class:"赛事",content:"拳头：2020全球总决赛最强选手20人！",spanName2:"span_date",date:"10-07"},
        {title:"title_no",spanName1:"video",class:"视频",content:"选手靠谱时刻：《科目四-反野》——SofM著-",spanName2:"span_date",date:"10-04"},
        {title:"title_no",spanName1:"video",class:"视频",content:"全球总决赛Moments-强心脏：JackeyLove篇",spanName2:"span_date",date:"10-05"},
        {title:"title_no",spanName1:"video",class:"视频",content:"十秒真粉丝：369贾克斯宗师之威一夫当关",spanName2:"span_date",date:"10-06"},
        {title:"title_no",spanName1:"competition",class:"赛事",content:"【搁浅说赛事】轻取MCX尽显统治力，SN能否冲击A组第一？",spanName2:"span_date",date:"10-07"}
    ]
    let html_competiton = '';
    for(let i=0; i<Af_news_competiton_arr.length; i++){
        html_competiton += '<li class="'+ Af_news_competiton_arr[i].title +'"><span class="'+ Af_news_competiton_arr[i].spanName1 +'">'+ Af_news_competiton_arr[i].class +'</span><a href="#">'+ Af_news_competiton_arr[i].content +'</a><span class="'+ Af_news_competiton_arr[i].spanName2 +'">'+ Af_news_competiton_arr[i].date +'</span></li>'
    }
    Af_news_competiton.innerHTML = html_competiton;

    //插入Af_news_total《攻略》列表
    let Af_news_strategy = document.getElementsByClassName("Af_news_total")[3];
    let Af_news_strategy_arr = [
        {title:"title_yes",spanName1:"",class:"",content:"从【魔宗卢锡安】聊起，魔宗的正确用法是怎样的？",spanName2:"span_date",date:""},
        {title:"title_no",spanName1:"video",class:"视频",content:"林小北云顶之弈：成型=吃分？S4神明猎T0级别阵容！无脑上钻",spanName2:"span_date",date:"10-07"},
        {title:"title_no",spanName1:"teach",class:"教学",content:"【莫甘娜打野攻略】世界赛有望登场？",spanName2:"span_date",date:"10-04"},
        {title:"title_no",spanName1:"teach",class:"教学",content:"Miss排位日记613期：神出鬼没的刺客！心理学恶魔小丑",spanName2:"span_date",date:"10-05"},
        {title:"title_no",spanName1:"video",class:"视频",content:"【苏御】王者手把手教你玩璐璐！一篇文章包学会！",spanName2:"span_date",date:"10-06"},
        {title:"title_no",spanName1:"teach",class:"教学",content:"新英雄沙弥拉全方位攻略！10.19非ban必选",spanName2:"span_date",date:"10-07"}
    ]
    let html_strategy = '';
    for(let i=0; i<Af_news_strategy_arr.length; i++){
        html_strategy += '<li class="'+ Af_news_strategy_arr[i].title +'"><span class="'+ Af_news_strategy_arr[i].spanName1 +'">'+ Af_news_strategy_arr[i].class +'</span><a href="#">'+ Af_news_strategy_arr[i].content +'</a><span class="'+ Af_news_strategy_arr[i].spanName2 +'">'+ Af_news_strategy_arr[i].date +'</span></li>'
    }
    Af_news_strategy.innerHTML = html_strategy;

    //插入Af_news_total《社区》列表
    let Af_news_society = document.getElementsByClassName("Af_news_total")[4];
    let Af_news_society_arr = [
        {title:"title_yes",spanName1:"",class:"",content:"【赛事排位沙漏】Pyosik独辟蹊径的千珏打法",spanName2:"span_date",date:""},
        {title:"title_no",spanName1:"entertainment",class:"娱乐",content:"Sofm教官又出科目四！你知道前三个科目分别是什么吗？",spanName2:"span_date",date:"10-07"},
        {title:"title_no",spanName1:"teach",class:"教学",content:"【韩大宝】我，厄斐琉斯，四面楚歌。",spanName2:"span_date",date:"10-04"},
        {title:"title_no",spanName1:"entertainment",class:"娱乐",content:"徐老师讲故事140：琴女之家在哪里？ 娑娜故事与彩蛋全解析！",spanName2:"span_date",date:"10-05"},
        {title:"title_no",spanName1:"video",class:"视频",content:"世界赛名场面超长合辑：你见过几个？",spanName2:"span_date",date:"10-06"},
        {title:"title_no",spanName1:"teach",class:"教学",content:"S10每日撸报第8期：JDG、LGD双双获胜，艾克连取MVP",spanName2:"span_date",date:"10-07"}
    ]
    let html_society = '';
    for(let i=0; i<Af_news_society_arr.length; i++){
        html_society += '<li class="'+ Af_news_society_arr[i].title +'"><span class="'+ Af_news_society_arr[i].spanName1 +'">'+ Af_news_society_arr[i].class +'</span><a href="#">'+ Af_news_society_arr[i].content +'</a><span class="'+ Af_news_society_arr[i].spanName2 +'">'+ Af_news_society_arr[i].date +'</span></li>'
    }
    Af_news_society.innerHTML = html_society;

    //Af_news列表切换
    let Af_news_list = document.getElementsByClassName("Af_news")[0].getElementsByTagName("li"); 
    let Af_news_tot_ul = document.getElementById("Af_news_tot");
    let Af_news_notice_ul = document.getElementById("Af_news_notice");
    let Af_news_competition_ul = document.getElementById("Af_news_competition");
    let Af_news_strategy_ul = document.getElementById("Af_news_strategy");
    let Af_news_society_ul = document.getElementById("Af_news_society");
    
    Af_news_list[0].onmouseover = ()=>{
        Af_news_tot_ul.style.display = "block";
        Af_news_notice_ul.style.display = "none";
        Af_news_competition_ul.style.display = "none";
        Af_news_strategy_ul.style.display = "none";
        Af_news_society_ul.style.display = "none";
    }

    Af_news_list[1].onmouseover = ()=>{
        Af_news_tot_ul.style.display = "none";
        Af_news_notice_ul.style.display = "block";
        Af_news_competition_ul.style.display = "none";
        Af_news_strategy_ul.style.display = "none";
        Af_news_society_ul.style.display = "none";
    }

    Af_news_list[2].onmouseover = ()=>{
        Af_news_tot_ul.style.display = "none";
        Af_news_notice_ul.style.display = "none";
        Af_news_competition_ul.style.display = "block";
        Af_news_strategy_ul.style.display = "none";
        Af_news_society_ul.style.display = "none";
    }

    Af_news_list[3].onmouseover = ()=>{
        Af_news_tot_ul.style.display = "none";
        Af_news_notice_ul.style.display = "none";
        Af_news_competition_ul.style.display = "none";
        Af_news_strategy_ul.style.display = "block";
        Af_news_society_ul.style.display = "none";
    }

    Af_news_list[4].onmouseover = ()=>{
        Af_news_tot_ul.style.display = "none";
        Af_news_notice_ul.style.display = "none";
        Af_news_competition_ul.style.display = "none";
        Af_news_strategy_ul.style.display = "none";
        Af_news_society_ul.style.display = "block";
    }

    Af_news_list[0].onmouseenter = ()=>{
        Af_news_list[0].style.color = "#1da6ba";
        Af_news_list[0].style.fontSize = "16px";
        Af_news_list[1].style.color = "#676767";
        Af_news_list[1].style.fontSize = "15px";
        Af_news_list[2].style.color = "#676767";
        Af_news_list[2].style.fontSize = "15px";
        Af_news_list[3].style.color = "#676767";
        Af_news_list[3].style.fontSize = "15px";
        Af_news_list[4].style.color = "#676767";
        Af_news_list[4].style.fontSize = "15px";
    }
    Af_news_list[1].onmouseenter = ()=>{
        Af_news_list[0].style.color = "#676767";
        Af_news_list[0].style.fontSize = "15px";
        Af_news_list[1].style.color = "#1da6ba";
        Af_news_list[1].style.fontSize = "16px";
        Af_news_list[2].style.color = "#676767";
        Af_news_list[2].style.fontSize = "15px";
        Af_news_list[3].style.color = "#676767";
        Af_news_list[3].style.fontSize = "15px";
        Af_news_list[4].style.color = "#676767";
        Af_news_list[4].style.fontSize = "15px";
    }
    Af_news_list[2].onmouseenter = ()=>{
        Af_news_list[0].style.color = "#676767";
        Af_news_list[0].style.fontSize = "15px";
        Af_news_list[1].style.color = "#676767";
        Af_news_list[1].style.fontSize = "15px";
        Af_news_list[2].style.color = "#1da6ba";
        Af_news_list[2].style.fontSize = "16px";
        Af_news_list[3].style.color = "#676767";
        Af_news_list[3].style.fontSize = "15px";
        Af_news_list[4].style.color = "#676767";
        Af_news_list[4].style.fontSize = "15px";
    }
    Af_news_list[3].onmouseenter = ()=>{
        Af_news_list[0].style.color = "#676767";
        Af_news_list[0].style.fontSize = "15px";
        Af_news_list[1].style.color = "#676767";
        Af_news_list[1].style.fontSize = "15px";
        Af_news_list[2].style.color = "#676767";
        Af_news_list[2].style.fontSize = "15px";
        Af_news_list[3].style.color = "#1da6ba";
        Af_news_list[3].style.fontSize = "16px";
        Af_news_list[4].style.color = "#676767";
        Af_news_list[4].style.fontSize = "15px";
    }
    Af_news_list[4].onmouseenter = ()=>{
        Af_news_list[0].style.color = "#676767";
        Af_news_list[0].style.fontSize = "15px";
        Af_news_list[1].style.color = "#676767";
        Af_news_list[1].style.fontSize = "15px";
        Af_news_list[2].style.color = "#676767";
        Af_news_list[2].style.fontSize = "15px";
        Af_news_list[3].style.color = "#1da6ba";
        Af_news_list[3].style.fontSize = "16px";
        Af_news_list[4].style.color = "#1da6ba";
        Af_news_list[4].style.fontSize = "16px";
    }

    //插入Bf图片链接集合
    let hot_activity_links = document.getElementsByClassName("hot_activity_links");
    
    //Bf层《正在进行》图片
    let hot_activity_ongoing_arr =[
        {url:"../images/content/全球总决赛竞猜.jpg",p1_content:"全球总决赛竞猜",p2_content:"29天后结束"},
        {url:"../images/content/城市峡谷生活圈.jpg",p1_content:"城市峡谷生活圈",p2_content:"1天后结束"},
        {url:"../images/content/欢度中秋活动.jpg",p1_content:"欢度中秋活动",p2_content:"2天后结束"}
    ]
    let html_hot_activity_ongoing = '';
    for(let i=0; i<hot_activity_ongoing_arr.length; i++){
        html_hot_activity_ongoing += '<li><a href="#"><img src="'+ hot_activity_ongoing_arr[i].url +'" alt=""><p class="hot_activity_links_p1">'+ hot_activity_ongoing_arr[i].p1_content +'</p><p class="hot_activity_links_p2">'+ hot_activity_ongoing_arr[i].p2_content +'</p></a></li>';
    }
    hot_activity_links[0].innerHTML = html_hot_activity_ongoing;

    //Bf层《正在进行》图片上下移动
    let hot_activity_ongoing_move = hot_activity_links[0].getElementsByTagName("li");
    for(let i=0; i<hot_activity_ongoing_move.length; i++){
        hot_activity_ongoing_move[i].onmouseover = ()=>{
            hot_activity_ongoing_move[i].style.top = "-10px";
        }
        hot_activity_ongoing_move[i].onmouseleave = ()=>{
            hot_activity_ongoing_move[i].style.top = "0px";
        }
    }
    
    //Bf层《商城特惠》图片
    let hot_activity_store_arr =[
        {url:"../images/content/奥术师 佐伊 至臻.jpg",p1_content:"奥术师 佐伊 至臻",p2_content:"113天后结束"},
        {url:"../images/content/神龙尊者.jpg",p1_content:"神龙尊者",p2_content:"23天后结束"},
        {url:"../images/content/世界赛神秘盒子.jpg",p1_content:"世界赛神秘盒子",p2_content:"33天后结束"}
    ]
    let html_hot_activity_store = '';
    for(let i=0; i<hot_activity_store_arr.length; i++){
        html_hot_activity_store += '<li><a href="#"><img src="'+ hot_activity_store_arr[i].url +'" alt=""><p class="hot_activity_links_p1">'+ hot_activity_store_arr[i].p1_content +'</p><p class="hot_activity_links_p2">'+ hot_activity_store_arr[i].p2_content +'</p></a></li>';
    }
    hot_activity_links[1].innerHTML = html_hot_activity_store;

    //Bf层《商城特惠》图片上下移动
    let hot_activity_store_move = hot_activity_links[1].getElementsByTagName("li");
    for(let i=0; i<hot_activity_store_move.length; i++){
        hot_activity_store_move[i].onmouseover = ()=>{
            hot_activity_store_move[i].style.top = "-10px";
        }
        hot_activity_store_move[i].onmouseleave = ()=>{
            hot_activity_store_move[i].style.top = "0px";
        }
    }

    //Bf层《长期活动》图片
    let hot_activity_longtime_arr =[
        {url:"../images/content/LOL组队专区.jpg",p1_content:"LOL组队专区",p2_content:"长期活动"},
        {url:"../images/content/英雄联盟：永恒星碑.jpg",p1_content:"英雄联盟：永恒星碑",p2_content:"长期活动"},
        {url:"../images/content/LPL × NIKE 队服站.jpg",p1_content:"LPL × NIKE 队服站",p2_content:"长期活动"}
    ]
    let html_hot_activity_longtime = '';
    for(let i=0; i<hot_activity_longtime_arr.length; i++){
        html_hot_activity_longtime += '<li><a href="#"><img src="'+ hot_activity_longtime_arr[i].url +'" alt=""><p class="hot_activity_links_p1">'+ hot_activity_longtime_arr[i].p1_content +'</p><p class="hot_activity_links_p2">'+ hot_activity_longtime_arr[i].p2_content +'</p></a></li>';
    }
    hot_activity_links[2].innerHTML = html_hot_activity_longtime;

    //Bf层《长期活动》图片上下移动
    let hot_activity_longtime_move = hot_activity_links[2].getElementsByTagName("li");
    for(let i=0; i<hot_activity_longtime_move.length; i++){
        hot_activity_longtime_move[i].onmouseover = ()=>{
            hot_activity_longtime_move[i].style.top = "-10px";
        }
        hot_activity_longtime_move[i].onmouseleave = ()=>{
            hot_activity_longtime_move[i].style.top = "0px";
        }
    }

    //鼠标移入hot_activity_nav切换hot_activity_links列表
    let hot_activity_nav = document.getElementsByClassName("hot_activity_nav")[0].getElementsByTagName("li");
    hot_activity_nav[0].onmouseover = ()=>{
        hot_activity_links[0].style.display = "block";
        hot_activity_links[1].style.display = "none";
        hot_activity_links[2].style.display = "none";
    }

    hot_activity_nav[1].onmouseover = ()=>{
        hot_activity_links[0].style.display = "none";
        hot_activity_links[1].style.display = "block";
        hot_activity_links[2].style.display = "none";
    }
    hot_activity_nav[2].onmouseover = ()=>{
        hot_activity_links[0].style.display = "none";
        hot_activity_links[1].style.display = "none";
        hot_activity_links[2].style.display = "block";
    }
    //鼠标移入hot_activity_nav的li后，字体变色变大
    hot_activity_nav[0].onmouseenter = ()=>{
        hot_activity_nav[0].style.color = "#1da6ba";
        hot_activity_nav[0].style.fontSize = "15px";
        hot_activity_nav[1].style.color = "#676767";
        hot_activity_nav[1].style.fontSize = "14px";
        hot_activity_nav[2].style.color = "#676767";
        hot_activity_nav[2].style.fontSize = "14px";
        hot_activity_nav[3].style.color = "#7ea1a6";
        hot_activity_nav[3].style.fontSize = "12px";
    }

    hot_activity_nav[1].onmouseenter = ()=>{
        hot_activity_nav[0].style.color = "#676767";
        hot_activity_nav[0].style.fontSize = "14px";
        hot_activity_nav[1].style.color = "#1da6ba";
        hot_activity_nav[1].style.fontSize = "15px";
        hot_activity_nav[2].style.color = "#676767";
        hot_activity_nav[2].style.fontSize = "14px";
        hot_activity_nav[3].style.color = "#7ea1a6";
        hot_activity_nav[3].style.fontSize = "12px";
    }

    hot_activity_nav[2].onmouseenter = ()=>{
        hot_activity_nav[0].style.color = "#676767";
        hot_activity_nav[0].style.fontSize = "14px";
        hot_activity_nav[1].style.color = "#676767";
        hot_activity_nav[1].style.fontSize = "14px";
        hot_activity_nav[2].style.color = "#1da6ba";
        hot_activity_nav[2].style.fontSize = "15px";
        hot_activity_nav[3].style.color = "#7ea1a6";
        hot_activity_nav[3].style.fontSize = "12px";
    }

    hot_activity_nav[3].onmouseenter = ()=>{
        hot_activity_nav[3].style.color = "#1da6ba";
        hot_activity_nav[3].style.fontSize = "13px";
    }



}

