window.onload = ()=>{
    //利用数组插入导航栏信息
    let head_nav_arr = [
    {title:"游戏资料",subtitle:"GAME INFO"},
    {title:"商城/合作",subtitle:"STORE"},
    {title:"社区互动",subtitle:"COMMUNITY"},
    {title:"赛事官网",subtitle:"ESPORTS"},
    {title:"自助系统",subtitle:"SYSTEM"},
    ];
    
    let head_nav_title = document.getElementsByClassName("head_nav_title");
    let head_nav_subtitle = document.getElementsByClassName("head_nav_subtitle");
    for(let i=0; i<head_nav_arr.length;i++){
        head_nav_title[i].innerHTML = head_nav_arr[i].title;
        head_nav_subtitle[i].innerHTML = head_nav_arr[i].subtitle;
    }

    //插入导航栏子菜单信息
    let header_Bf_inner_arr = [
        {url:"#",title:"游戏下载"},
        {url:"#",title:"点券充值"},
        {url:"#",title:"官方社区"},
        {url:"#",class:"logo_h",title:"LPL职业联赛"},
        {url:"#",title:"联系客服"},
        {url:"#",title:"新手指引"},
        {url:"#",class:"logo_h",title:"道聚城"},
        {url:"#",title:"视频中心"},
        {url:"#",title:"LDL发展联赛"},
        {url:"#",class:"logo_n",title:"转区系统"},
        {url:"#",title:"资料库"},
        {url:"#",title:"周边商城"},
        {url:"#",title:"官方论坛"},
        {url:"#",class:"logo_h",title:"全球总决赛"},
        {url:"#",class:"logo_h",title:"封号查询"},
        {url:"#",class:"logo_n",title:"云顶之弈"},
        {url:"#",title:"LOL桌游"},
        {url:"#",title:"官方微信"},
        {url:"#",title:"城市英雄争霸赛"},
        {url:"#",title:"账号注销"},
        {url:"#",class:"logo_n",title:"攻略中心"},
        {url:"#",title:"网吧特权"},
        {url:"#",title:"官方微博"},
        {url:"#",class:"logo_n",title:"季中杯"},
        {url:"#",class:"logo_n",title:"信誉分系统"},
        {url:"#",title:"开发者基地"},
        {url:"#",title:"电竞小说"},
        {url:"#",title:"玩家创作馆"},
        {url:"#",title:"德玛西亚杯"},
        {url:"#",title:"服务器状态查询"},
        {url:"#",title:"海克斯战利品库"},
        {url:"#",class:"logo_n",title:"作者入驻计划"},
        {url:"#",title:"玩家服务"},
        {url:"#",title:"全国高校联赛"},
        {url:"#",title:"秩序殿堂"},
        {url:"#",title:"英雄联盟宇宙"},
        {url:"#",title:""},
        {url:"#",class:"logo_n",title:"LOL组队专区"},
        {url:"#",class:"logo_n",title:"云顶之弈公开赛"},
        {url:"#",title:"峡谷之巅"}
    ];
    let header_Bf_inner = document.getElementById("header_Bf_inner");
    let html = '';
    for(let i=0; i<header_Bf_inner_arr.length; i++){
        html += '<li><a href="'+header_Bf_inner_arr[i].url+'">'+'<div class = "'+ header_Bf_inner_arr[i].class +'"></div>'+header_Bf_inner_arr[i].title+'</a></li>';
    }
    header_Bf_inner.innerHTML = html;

    //绑定鼠标移入head_nav事件
    let head_nav = document.getElementById("head_nav");
    let header_Bf = document.getElementById("header_Bf");
    head_nav.onmouseover = ()=>{
        header_Bf.style.display = "block";
    }
    //绑定鼠标移出head_nav事件
    header_Bf.onmouseleave = ()=>{
        header_Bf.style.display = "none";
    }
    
    let head_search = document.getElementsByClassName("head_search")[0];
    let head_search_onclick = document.getElementsByClassName("head_search_onclick")[0];
    let head_search_close = document.getElementsByClassName("head_search_close")[0];
    //绑定搜索按钮点击事件
    head_search.onclick = ()=>{
        head_search_onclick.style.display = "block";
    }
    //绑定关闭搜索按钮点击事件
    head_search_close.onclick = ()=>{
        head_search_onclick.style.display = "none";
    }

    //绑定鼠标移入出现下载二维码事件
    let head_app = document.getElementsByClassName("head_app")[0];
    let head_app_hover = document.getElementsByClassName("head_app_hover")[0];
    head_app.onmouseover = ()=>{
        head_app_hover.style.display = "block";
    }
    //移出
    head_app_hover.onmouseleave = ()=>{
        head_app_hover.style.display = "none";
    }

    //绑定鼠标移入出现登录信息事件
    let head_login = document.getElementsByClassName("head_login")[0];
    let head_login_hover = document.getElementsByClassName("head_login_hover")[0];
    head_login.onmouseover = ()=>{
        head_login_hover.style.display = "block";
    }
    //移出
    head_login_hover.onmouseleave = ()=>{
        head_login_hover.style.display = "none";
    }

}



